module.exports = "lwb-peer-bad@1.0.0"
