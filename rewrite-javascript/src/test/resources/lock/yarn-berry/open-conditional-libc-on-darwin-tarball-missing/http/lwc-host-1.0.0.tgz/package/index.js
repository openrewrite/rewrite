module.exports = "lwc-host@1.0.0"
