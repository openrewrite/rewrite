module.exports = "lwc-linux-gnu@1.0.0"
