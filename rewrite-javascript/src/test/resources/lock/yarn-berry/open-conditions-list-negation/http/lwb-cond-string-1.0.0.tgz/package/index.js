module.exports = "lwb-cond-string@1.0.0"
