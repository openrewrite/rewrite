module.exports = "lwb-cond-list@1.0.0"
