module.exports = "lwb-cond-neg@1.0.0"
