module.exports = "lwb-x-mid@1.0.0"
