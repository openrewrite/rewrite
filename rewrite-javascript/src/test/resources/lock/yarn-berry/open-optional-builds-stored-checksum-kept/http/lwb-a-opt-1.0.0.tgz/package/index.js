module.exports = "lwb-a-opt@1.0.0"
