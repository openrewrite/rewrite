module.exports = "lwb-y-cond@1.0.0"
