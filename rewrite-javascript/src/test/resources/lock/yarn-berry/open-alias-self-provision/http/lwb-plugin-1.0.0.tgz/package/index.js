module.exports = "lwb-plugin@1.0.0"
