module.exports = "lwb-host@1.0.0"
