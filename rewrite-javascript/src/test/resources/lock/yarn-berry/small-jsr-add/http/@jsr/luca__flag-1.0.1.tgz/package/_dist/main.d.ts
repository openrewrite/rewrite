/**
 * Print the progress flag to the terminal with a size of 24x80 characters.
 */ export declare function printProgress(): void;
//# sourceMappingURL=main.d.ts.map