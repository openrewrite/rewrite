module.exports = "lwb-p-parent@1.0.0"
