module.exports = "lwb-b-hard@1.0.0"
