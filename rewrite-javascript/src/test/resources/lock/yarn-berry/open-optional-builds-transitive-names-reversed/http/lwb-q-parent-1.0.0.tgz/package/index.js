module.exports = "lwb-q-parent@1.0.0"
