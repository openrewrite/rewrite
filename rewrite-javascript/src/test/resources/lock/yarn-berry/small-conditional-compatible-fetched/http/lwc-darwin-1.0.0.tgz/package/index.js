module.exports = "lwc-darwin@1.0.0"
